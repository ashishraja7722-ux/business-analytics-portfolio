# Business Analytics Dashboard Suite

An interactive collection of 5 mock dashboards covering sales performance, customer segmentation (RFM), employee attrition, user funnel analysis, and budget vs. actual spend. Built with React, Recharts, and Tailwind CSS, with mock data structured so it can be swapped for a real dataset.

## Projects included

1. **Sales Performance Dashboard** — revenue by region, monthly trend, top products
2. **Customer Segmentation (RFM)** — segment distribution, average spend per segment
3. **Employee Attrition Analysis** — reasons for leaving, attrition rate by department
4. **User Funnel Analysis** — visit-to-purchase funnel with drop-off at each stage
5. **Budget vs. Actual Spend** — budget vs. actual by department, variance table

## Tech stack

- React 18
- Vite
- Tailwind CSS 4
- Recharts (charts)
- Lucide React (icons)

## Getting started

```bash
npm install
npm run dev
```

Then open the local URL Vite prints in your terminal.

## Build for production

```bash
npm run build
npm run preview
```

## Notes

All data in this project is mock data, defined at the top of `src/Dashboard.jsx`. Swap in a real dataset there to make each dashboard reflect actual analysis.
