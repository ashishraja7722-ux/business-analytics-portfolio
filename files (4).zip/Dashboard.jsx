import React, { useState } from "react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell,
} from "recharts";
import {
  TrendingUp, Users, UserMinus, Filter, Wallet, Quote, Radio, ArrowDown,
} from "lucide-react";

const colors = {
  bg: "#12151C",
  panel: "#1A1E29",
  border: "#262B3A",
  amber: "#E8A33D",
  amberSoft: "#E8A33D33",
  teal: "#4FD1C5",
  tealSoft: "#4FD1C533",
  rose: "#E8735F",
  roseSoft: "#E8735F33",
  violet: "#9C8CF0",
  textPrimary: "#EDEAE3",
  textMuted: "#8B93A7",
  textFaint: "#5A6178",
};

const fonts = {
  display: "'Space Grotesk', sans-serif",
  body: "'Inter', sans-serif",
  mono: "'IBM Plex Mono', monospace",
};

const PROJECTS = [
  {
    id: "sales",
    code: "SALES-01",
    title: "Sales Performance Dashboard",
    icon: TrendingUp,
    pitch: "Which products and regions make the most money, and when sales peak.",
    tools: ["SQL", "PYTHON", "POWER BI"],
    bullet:
      "Built an interactive sales dashboard analyzing $568K in revenue across 5 regions and 12 months, identifying the top-performing region driving 25% of total sales.",
  },
  {
    id: "rfm",
    code: "RFM-02",
    title: "Customer Segmentation (RFM)",
    icon: Users,
    pitch: "Grouping customers by buying behavior so the business targets the right offers at the right people.",
    tools: ["PYTHON", "PANDAS", "K-MEANS"],
    bullet:
      "Segmented 1,850 customers into 5 behavioral groups using RFM analysis, flagging that 17% were 'At Risk' and needed immediate retention outreach.",
  },
  {
    id: "attrition",
    code: "ATTR-03",
    title: "Employee Attrition Analysis",
    icon: UserMinus,
    pitch: "Finding the top reasons employees quit, so the company can fix them.",
    tools: ["PYTHON", "LOGISTIC REGRESSION", "EXCEL"],
    bullet:
      "Analyzed HR data across 5 departments to uncover a 17.4% overall attrition rate, with Support seeing the highest turnover at 27%, driven mainly by compensation.",
  },
  {
    id: "funnel",
    code: "FUNL-04",
    title: "User Funnel Analysis",
    icon: Filter,
    pitch: "Finding the exact step where users abandon signup, so the team knows what to fix first.",
    tools: ["SQL", "GOOGLE ANALYTICS", "PYTHON"],
    bullet:
      "Mapped the full user funnel from visit to purchase, identifying a 75% drop-off between Site Visit and Sign-Up as the single biggest fix opportunity.",
  },
  {
    id: "budget",
    code: "BUDG-05",
    title: "Budget vs. Actual Spend",
    icon: Wallet,
    pitch: "Comparing planned vs. actual spending to flag which departments are going over budget, and by how much.",
    tools: ["EXCEL", "SQL", "POWER BI"],
    bullet:
      "Compared budgeted vs. actual spend across 5 departments, flagging Marketing as 15.4% over budget and recommending reallocation from underspending teams.",
  },
];

const salesByRegion = [
  { region: "North", revenue: 128400 },
  { region: "South", revenue: 96200 },
  { region: "East", revenue: 143800 },
  { region: "West", revenue: 87500 },
  { region: "Central", revenue: 112300 },
];

const monthlyTrend = [
  { month: "Jan", revenue: 68000 }, { month: "Feb", revenue: 71500 },
  { month: "Mar", revenue: 79800 }, { month: "Apr", revenue: 74200 },
  { month: "May", revenue: 82100 }, { month: "Jun", revenue: 91400 },
  { month: "Jul", revenue: 88700 }, { month: "Aug", revenue: 95300 },
  { month: "Sep", revenue: 102600 }, { month: "Oct", revenue: 98100 },
  { month: "Nov", revenue: 110400 }, { month: "Dec", revenue: 126800 },
];

const topProducts = [
  { name: "Wireless Earbuds Pro", revenue: 42300, units: 1210 },
  { name: "Smart Fitness Band", revenue: 38900, units: 1450 },
  { name: "4K Action Camera", revenue: 35200, units: 680 },
  { name: "Portable Blender", revenue: 28700, units: 2100 },
  { name: "Ergonomic Office Chair", revenue: 26400, units: 340 },
];

const rfmSegments = [
  { segment: "Champions", count: 420, avgSpend: 890, color: colors.teal },
  { segment: "Loyal", count: 680, avgSpend: 540, color: colors.amber },
  { segment: "At Risk", count: 310, avgSpend: 260, color: colors.rose },
  { segment: "New", count: 250, avgSpend: 120, color: colors.violet },
  { segment: "Lost", count: 190, avgSpend: 40, color: colors.textFaint },
];

const attritionReasons = [
  { reason: "Compensation", pct: 32 },
  { reason: "Work-Life Balance", pct: 24 },
  { reason: "Limited Growth", pct: 21 },
  { reason: "Management", pct: 14 },
  { reason: "Other", pct: 9 },
];

const attritionByDept = [
  { dept: "Support", rate: 27 },
  { dept: "Sales", rate: 22 },
  { dept: "Operations", rate: 18 },
  { dept: "Marketing", rate: 15 },
  { dept: "Engineering", rate: 11 },
];

const funnelSteps = [
  { step: "Site Visit", users: 50000 },
  { step: "Sign Up", users: 12500 },
  { step: "Activated Account", users: 8100 },
  { step: "Added to Cart", users: 4200 },
  { step: "Completed Purchase", users: 2650 },
];

const budgetVsActual = [
  { dept: "Marketing", budget: 120000, actual: 138500 },
  { dept: "Engineering", budget: 250000, actual: 241200 },
  { dept: "Sales", budget: 180000, actual: 195400 },
  { dept: "Operations", budget: 90000, actual: 84300 },
  { dept: "HR", budget: 60000, actual: 58900 },
];

function fmtMoney(n) {
  return "$" + n.toLocaleString("en-US");
}

function KpiCard({ label, value, sub }) {
  return (
    <div style={{ background: colors.panel, border: `1px solid ${colors.border}` }} className="rounded-lg p-4 flex-1 min-w-[140px]">
      <div style={{ color: colors.textMuted, fontFamily: fonts.mono, fontSize: 11, letterSpacing: 1 }}>{label}</div>
      <div style={{ color: colors.textPrimary, fontFamily: fonts.mono, fontSize: 24, marginTop: 6 }}>{value}</div>
      {sub && <div style={{ color: colors.textFaint, fontFamily: fonts.body, fontSize: 12, marginTop: 2 }}>{sub}</div>}
    </div>
  );
}

function Panel({ title, children, right }) {
  return (
    <div style={{ background: colors.panel, border: `1px solid ${colors.border}` }} className="rounded-lg p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 style={{ color: colors.textPrimary, fontFamily: fonts.display, fontSize: 15, fontWeight: 600, letterSpacing: 0.3 }}>{title}</h3>
        {right}
      </div>
      {children}
    </div>
  );
}

function ChartTooltipStyle() {
  return { background: colors.bg, border: `1px solid ${colors.border}`, borderRadius: 8, fontFamily: fonts.mono, fontSize: 12, color: colors.textPrimary };
}

function ResumeBullet({ text }) {
  return (
    <div style={{ background: colors.amberSoft, border: `1px dashed ${colors.amber}` }} className="rounded-lg p-4 flex gap-3 items-start">
      <Quote size={16} color={colors.amber} style={{ marginTop: 3, flexShrink: 0 }} />
      <div>
        <div style={{ color: colors.amber, fontFamily: fonts.mono, fontSize: 10, letterSpacing: 1.5, marginBottom: 4 }}>RESUME BULLET</div>
        <div style={{ color: colors.textPrimary, fontFamily: fonts.body, fontSize: 13.5, lineHeight: 1.5 }}>{text}</div>
      </div>
    </div>
  );
}

function SalesView() {
  return (
    <div className="space-y-5">
      <div className="flex flex-wrap gap-3">
        <KpiCard label="TOTAL REVENUE" value="$568.2K" sub="across 5 regions" />
        <KpiCard label="ORDERS" value="8,942" sub="trailing 12 months" />
        <KpiCard label="AVG ORDER VALUE" value="$63.53" />
        <KpiCard label="TOP REGION" value="East" sub="25% of revenue" />
      </div>
      <div className="grid md:grid-cols-2 gap-5">
        <Panel title="Revenue by Region">
          <ResponsiveContainer width="100%" height={230}>
            <BarChart data={salesByRegion}>
              <CartesianGrid stroke={colors.border} vertical={false} />
              <XAxis dataKey="region" tick={{ fill: colors.textMuted, fontFamily: fonts.mono, fontSize: 11 }} axisLine={{ stroke: colors.border }} tickLine={false} />
              <YAxis tick={{ fill: colors.textMuted, fontFamily: fonts.mono, fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v / 1000}K`} />
              <Tooltip contentStyle={ChartTooltipStyle()} formatter={(v) => fmtMoney(v)} cursor={{ fill: colors.border, opacity: 0.3 }} />
              <Bar dataKey="revenue" fill={colors.amber} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Panel>
        <Panel title="Monthly Revenue Trend">
          <ResponsiveContainer width="100%" height={230}>
            <LineChart data={monthlyTrend}>
              <CartesianGrid stroke={colors.border} vertical={false} />
              <XAxis dataKey="month" tick={{ fill: colors.textMuted, fontFamily: fonts.mono, fontSize: 10 }} axisLine={{ stroke: colors.border }} tickLine={false} />
              <YAxis tick={{ fill: colors.textMuted, fontFamily: fonts.mono, fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v / 1000}K`} />
              <Tooltip contentStyle={ChartTooltipStyle()} formatter={(v) => fmtMoney(v)} />
              <Line type="monotone" dataKey="revenue" stroke={colors.teal} strokeWidth={2} dot={{ r: 3, fill: colors.teal }} />
            </LineChart>
          </ResponsiveContainer>
        </Panel>
      </div>
      <Panel title="Top 5 Products by Revenue">
        <div className="space-y-2">
          {topProducts.map((p, i) => (
            <div key={p.name} className="flex items-center justify-between py-2" style={{ borderBottom: i < topProducts.length - 1 ? `1px solid ${colors.border}` : "none" }}>
              <div className="flex items-center gap-3">
                <span style={{ color: colors.textFaint, fontFamily: fonts.mono, fontSize: 12 }}>{String(i + 1).padStart(2, "0")}</span>
                <span style={{ color: colors.textPrimary, fontFamily: fonts.body, fontSize: 13.5 }}>{p.name}</span>
              </div>
              <div className="flex items-center gap-4">
                <span style={{ color: colors.textMuted, fontFamily: fonts.mono, fontSize: 11 }}>{p.units.toLocaleString()} units</span>
                <span style={{ color: colors.amber, fontFamily: fonts.mono, fontSize: 13 }}>{fmtMoney(p.revenue)}</span>
              </div>
            </div>
          ))}
        </div>
      </Panel>
      <ResumeBullet text={PROJECTS[0].bullet} />
    </div>
  );
}

function RfmView() {
  return (
    <div className="space-y-5">
      <div className="grid md:grid-cols-2 gap-5">
        <Panel title="Segment Distribution">
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie data={rfmSegments} dataKey="count" nameKey="segment" innerRadius={55} outerRadius={90} paddingAngle={3}>
                {rfmSegments.map((s) => <Cell key={s.segment} fill={s.color} stroke={colors.panel} strokeWidth={2} />)}
              </Pie>
              <Tooltip contentStyle={ChartTooltipStyle()} formatter={(v, n) => [`${v} customers`, n]} />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex flex-wrap gap-3 mt-2 justify-center">
            {rfmSegments.map((s) => (
              <div key={s.segment} className="flex items-center gap-1.5">
                <span style={{ width: 8, height: 8, borderRadius: 2, background: s.color, display: "inline-block" }} />
                <span style={{ color: colors.textMuted, fontFamily: fonts.mono, fontSize: 10.5 }}>{s.segment}</span>
              </div>
            ))}
          </div>
        </Panel>
        <Panel title="Avg. Spend per Segment">
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={rfmSegments} layout="vertical" margin={{ left: 10 }}>
              <CartesianGrid stroke={colors.border} horizontal={false} />
              <XAxis type="number" tick={{ fill: colors.textMuted, fontFamily: fonts.mono, fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={(v) => `$${v}`} />
              <YAxis type="category" dataKey="segment" tick={{ fill: colors.textMuted, fontFamily: fonts.mono, fontSize: 11 }} axisLine={false} tickLine={false} width={80} />
              <Tooltip contentStyle={ChartTooltipStyle()} formatter={(v) => `$${v}`} cursor={{ fill: colors.border, opacity: 0.3 }} />
              <Bar dataKey="avgSpend" radius={[0, 4, 4, 0]}>
                {rfmSegments.map((s) => <Cell key={s.segment} fill={s.color} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </Panel>
      </div>
      <ResumeBullet text={PROJECTS[1].bullet} />
    </div>
  );
}

function AttritionView() {
  return (
    <div className="space-y-5">
      <div className="flex flex-wrap gap-3">
        <KpiCard label="OVERALL ATTRITION" value="17.4%" sub="trailing 12 months" />
        <KpiCard label="HIGHEST-RISK DEPT" value="Support" sub="27% turnover" />
        <KpiCard label="TOP DRIVER" value="Pay" sub="32% cite compensation" />
      </div>
      <div className="grid md:grid-cols-2 gap-5">
        <Panel title="Reasons for Leaving">
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={attritionReasons} layout="vertical" margin={{ left: 10 }}>
              <CartesianGrid stroke={colors.border} horizontal={false} />
              <XAxis type="number" tick={{ fill: colors.textMuted, fontFamily: fonts.mono, fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v}%`} />
              <YAxis type="category" dataKey="reason" tick={{ fill: colors.textMuted, fontFamily: fonts.mono, fontSize: 10.5 }} axisLine={false} tickLine={false} width={110} />
              <Tooltip contentStyle={ChartTooltipStyle()} formatter={(v) => `${v}%`} cursor={{ fill: colors.border, opacity: 0.3 }} />
              <Bar dataKey="pct" fill={colors.rose} radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Panel>
        <Panel title="Attrition Rate by Department">
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={attritionByDept}>
              <CartesianGrid stroke={colors.border} vertical={false} />
              <XAxis dataKey="dept" tick={{ fill: colors.textMuted, fontFamily: fonts.mono, fontSize: 10 }} axisLine={{ stroke: colors.border }} tickLine={false} />
              <YAxis tick={{ fill: colors.textMuted, fontFamily: fonts.mono, fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v}%`} />
              <Tooltip contentStyle={ChartTooltipStyle()} formatter={(v) => `${v}%`} cursor={{ fill: colors.border, opacity: 0.3 }} />
              <Bar dataKey="rate" fill={colors.amber} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Panel>
      </div>
      <ResumeBullet text={PROJECTS[2].bullet} />
    </div>
  );
}

function FunnelView() {
  const max = funnelSteps[0].users;
  return (
    <div className="space-y-5">
      <Panel title="Visit → Purchase Funnel">
        <div className="space-y-3">
          {funnelSteps.map((s, i) => {
            const widthPct = (s.users / max) * 100;
            const prev = i > 0 ? funnelSteps[i - 1].users : null;
            const convPct = prev ? ((s.users / prev) * 100).toFixed(1) : null;
            const dropPct = prev ? (100 - convPct).toFixed(1) : null;
            const isBiggestDrop = i === 1;
            return (
              <div key={s.step}>
                {i > 0 && (
                  <div className="flex items-center gap-2 pl-2 mb-1">
                    <ArrowDown size={12} color={isBiggestDrop ? colors.rose : colors.textFaint} />
                    <span style={{ color: isBiggestDrop ? colors.rose : colors.textFaint, fontFamily: fonts.mono, fontSize: 11 }}>
                      {convPct}% converted · {dropPct}% dropped off{isBiggestDrop ? "  ← biggest gap" : ""}
                    </span>
                  </div>
                )}
                <div className="flex items-center gap-3">
                  <div
                    style={{
                      width: `${widthPct}%`,
                      background: isBiggestDrop === false && i > 0 ? colors.tealSoft : colors.amberSoft,
                      border: `1px solid ${i > 0 ? colors.teal : colors.amber}`,
                      minWidth: 120,
                    }}
                    className="rounded-md py-2.5 px-4 flex items-center justify-between"
                  >
                    <span style={{ color: colors.textPrimary, fontFamily: fonts.body, fontSize: 13 }}>{s.step}</span>
                    <span style={{ color: colors.textPrimary, fontFamily: fonts.mono, fontSize: 13 }}>{s.users.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </Panel>
      <ResumeBullet text={PROJECTS[3].bullet} />
    </div>
  );
}

function BudgetView() {
  return (
    <div className="space-y-5">
      <Panel title="Budget vs. Actual by Department">
        <ResponsiveContainer width="100%" height={260}>
          <BarChart data={budgetVsActual}>
            <CartesianGrid stroke={colors.border} vertical={false} />
            <XAxis dataKey="dept" tick={{ fill: colors.textMuted, fontFamily: fonts.mono, fontSize: 10.5 }} axisLine={{ stroke: colors.border }} tickLine={false} />
            <YAxis tick={{ fill: colors.textMuted, fontFamily: fonts.mono, fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v / 1000}K`} />
            <Tooltip contentStyle={ChartTooltipStyle()} formatter={(v) => fmtMoney(v)} cursor={{ fill: colors.border, opacity: 0.3 }} />
            <Bar dataKey="budget" name="Budget" fill={colors.textFaint} radius={[4, 4, 0, 0]} />
            <Bar dataKey="actual" name="Actual" fill={colors.amber} radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
        <div className="flex gap-4 justify-center mt-1">
          <div className="flex items-center gap-1.5"><span style={{ width: 8, height: 8, background: colors.textFaint, display: "inline-block", borderRadius: 2 }} /><span style={{ color: colors.textMuted, fontFamily: fonts.mono, fontSize: 10.5 }}>Budget</span></div>
          <div className="flex items-center gap-1.5"><span style={{ width: 8, height: 8, background: colors.amber, display: "inline-block", borderRadius: 2 }} /><span style={{ color: colors.textMuted, fontFamily: fonts.mono, fontSize: 10.5 }}>Actual</span></div>
        </div>
      </Panel>
      <Panel title="Variance">
        <div className="space-y-2">
          {budgetVsActual.map((d, i) => {
            const variance = ((d.actual - d.budget) / d.budget) * 100;
            const over = variance > 0;
            return (
              <div key={d.dept} className="flex items-center justify-between py-2" style={{ borderBottom: i < budgetVsActual.length - 1 ? `1px solid ${colors.border}` : "none" }}>
                <span style={{ color: colors.textPrimary, fontFamily: fonts.body, fontSize: 13.5 }}>{d.dept}</span>
                <div className="flex items-center gap-3">
                  <span style={{ color: colors.textMuted, fontFamily: fonts.mono, fontSize: 11.5 }}>{fmtMoney(d.actual)} / {fmtMoney(d.budget)}</span>
                  <span style={{ color: over ? colors.rose : colors.teal, fontFamily: fonts.mono, fontSize: 13, minWidth: 60, textAlign: "right" }}>
                    {over ? "+" : ""}{variance.toFixed(1)}%
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </Panel>
      <ResumeBullet text={PROJECTS[4].bullet} />
    </div>
  );
}

const VIEWS = { sales: SalesView, rfm: RfmView, attrition: AttritionView, funnel: FunnelView, budget: BudgetView };

export default function BusinessAnalyticsPortfolio() {
  const [active, setActive] = useState("sales");
  const activeProject = PROJECTS.find((p) => p.id === active);
  const ActiveView = VIEWS[active];

  return (
    <div style={{ background: colors.bg, fontFamily: fonts.body, minHeight: "100vh" }} className="w-full">
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap');`}</style>

      <div className="flex flex-col md:flex-row min-h-screen">
        {/* Sidebar */}
        <div style={{ background: colors.panel, borderRight: `1px solid ${colors.border}` }} className="w-full md:w-72 flex-shrink-0 p-5">
          <div className="flex items-center gap-2 mb-1">
            <span style={{ width: 7, height: 7, borderRadius: "50%", background: colors.teal, display: "inline-block" }} className="animate-pulse" />
            <span style={{ color: colors.teal, fontFamily: fonts.mono, fontSize: 10.5, letterSpacing: 1.5 }}>MOCK DATA · DEMO</span>
          </div>
          <h1 style={{ color: colors.textPrimary, fontFamily: fonts.display, fontSize: 20, fontWeight: 700, marginTop: 6 }}>
            Analytics Portfolio
          </h1>
          <p style={{ color: colors.textMuted, fontFamily: fonts.body, fontSize: 12.5, marginTop: 4, lineHeight: 1.5 }}>
            5 resume-ready projects. Swap in real data to make each one yours.
          </p>

          <div className="mt-6 space-y-1.5">
            {PROJECTS.map((p) => {
              const Icon = p.icon;
              const isActive = p.id === active;
              return (
                <button
                  key={p.id}
                  onClick={() => setActive(p.id)}
                  style={{
                    background: isActive ? colors.amberSoft : "transparent",
                    borderLeft: `2px solid ${isActive ? colors.amber : "transparent"}`,
                  }}
                  className="w-full text-left rounded-r-md pl-3 pr-2 py-2.5 flex items-start gap-2.5 transition-colors hover:bg-white/5"
                >
                  <Icon size={16} color={isActive ? colors.amber : colors.textMuted} style={{ marginTop: 2, flexShrink: 0 }} />
                  <div>
                    <div style={{ color: isActive ? colors.amber : colors.textFaint, fontFamily: fonts.mono, fontSize: 10, letterSpacing: 1 }}>{p.code}</div>
                    <div style={{ color: isActive ? colors.textPrimary : colors.textMuted, fontFamily: fonts.body, fontSize: 13, fontWeight: 500, marginTop: 1 }}>{p.title}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Main */}
        <div className="flex-1 p-5 md:p-8 max-w-4xl">
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <span style={{ color: colors.textFaint, fontFamily: fonts.mono, fontSize: 11, letterSpacing: 1 }}>{activeProject.code}</span>
              <Radio size={11} color={colors.textFaint} />
            </div>
            <h2 style={{ color: colors.textPrimary, fontFamily: fonts.display, fontSize: 24, fontWeight: 700 }}>{activeProject.title}</h2>
            <p style={{ color: colors.textMuted, fontFamily: fonts.body, fontSize: 13.5, marginTop: 6, maxWidth: 560, lineHeight: 1.5 }}>{activeProject.pitch}</p>
            <div className="flex flex-wrap gap-2 mt-3">
              {activeProject.tools.map((t) => (
                <span key={t} style={{ background: colors.border, color: colors.textMuted, fontFamily: fonts.mono, fontSize: 10, letterSpacing: 0.8 }} className="px-2 py-1 rounded">
                  {t}
                </span>
              ))}
            </div>
          </div>

          <ActiveView />
        </div>
      </div>
    </div>
  );
}
